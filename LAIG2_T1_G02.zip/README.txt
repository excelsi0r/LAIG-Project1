Turma 1
- Nuno Neto - 201406003
- Vasco Pereira - 201302819

Toda a nova documenta�ao associdada ao trabalho 2 come�a com a frase: 
'Documentation refering to the second part of the project'